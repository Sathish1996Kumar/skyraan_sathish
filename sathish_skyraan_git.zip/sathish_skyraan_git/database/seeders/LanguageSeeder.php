<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Language;

class LanguageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $languages = [
            ['language_name' => 'English', 'language_code' => 'en'],
            ['language_name' => 'Tamil',   'language_code' => 'ta'],
            ['language_name' => 'Hindi',   'language_code' => 'hi'],
            ['language_name' => 'French',  'language_code' => 'fr'],
            ['language_name' => 'Kannada', 'language_code' => 'kn'],
        ];

        Language::insert($languages);
    }
}
