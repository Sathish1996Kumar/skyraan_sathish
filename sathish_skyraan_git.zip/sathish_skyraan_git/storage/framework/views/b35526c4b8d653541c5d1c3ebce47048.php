<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <h2>Category List</h2>

        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary mb-3">Add Category</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success flash-message"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('failure')): ?>
            <div class="alert alert-danger flash-message"><?php echo e(session('failure')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Action</th>
            </tr>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cat->id); ?></td>
                    <td><?php echo e($cat->category_name); ?></td>
                    <td><?php echo e($cat->description); ?></td>
                    <td>
                        <?php if($cat->category_image): ?>
                            <img src="<?php echo e(asset('uploads/category/' . $cat->category_image)); ?>" width="80" style="max-height:70px;">
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('categories.edit', $cat->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="<?php echo e(route('categories.delete', $cat->id)); ?>" class="btn btn-sm btn-danger"
                            onclick="return confirm('Delete?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<script>
    setTimeout(function() {
        let messages = document.querySelectorAll('.flash-message');
        messages.forEach(function(msg) {
            msg.style.transition = "opacity 0.5s";
            msg.style.opacity = "0";
            setTimeout(() => msg.remove(), 500);
        });
    }, 2000); // 3 seconds
</script>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/categories/index.blade.php ENDPATH**/ ?>