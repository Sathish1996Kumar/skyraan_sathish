<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h2>Edit Book</h2>

    <form action="<?php echo e(route('books.update', $book->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Book Name</label>
            <input type="text" name="book_name" class="form-control" value="<?php echo e($book->book_name); ?>" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"><?php echo e($book->description); ?></textarea>
        </div>

        <div class="mb-3">
            <label>Author</label>
            <input type="text" name="author" class="form-control" value="<?php echo e($book->author); ?>" required>
        </div>

        <div class="mb-3">
            <label>Publisher Date</label>
            <input type="date" name="publisher_date" class="form-control" value="<?php echo e($book->publisher_date); ?>">
        </div>

        <div class="mb-3">
            <label>Current Thumbnail</label><br>
            <?php if($book->book_thumb_image): ?>
                <img src="<?php echo e(asset('uploads/books/thumb/'.$book->book_thumb_image)); ?>" width="90"><br><br>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label>Upload New Thumbnail</label>
            <input type="file" name="book_thumb_image" class="form-control">
        </div>

        <div class="mb-3">
            <label>Current PDF</label><br>
            <?php if($book->book_pdf): ?>
                <a href="<?php echo e(asset('uploads/books/pdf/'.$book->book_pdf)); ?>" target="_blank">Open PDF</a><br><br>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label>Upload New PDF</label>
            <input type="file" name="book_pdf" class="form-control">
        </div>

        <div class="mb-3">
            <label>Select Language</label>
            <select name="language_id" class="form-control" required>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($lang->id); ?>" <?php echo e($book->language_id == $lang->id ? 'selected' : ''); ?>>
                        <?php echo e($lang->language_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Select Category</label>
            <select name="category_id" class="form-control" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e($book->category_id == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->category_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button class="btn btn-success">Update</button>
        <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">Back</a>

    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/books/edit.blade.php ENDPATH**/ ?>