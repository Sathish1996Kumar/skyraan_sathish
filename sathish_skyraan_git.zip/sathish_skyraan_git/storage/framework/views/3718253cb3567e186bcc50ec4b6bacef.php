<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h2>Add Book</h2>

    <form action="<?php echo e(route('books.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Book Name</label>
            <input type="text" name="book_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label>Author</label>
            <input type="text" name="author" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Publisher Date</label>
            <input type="date" name="publisher_date" class="form-control">
        </div>

        <div class="mb-3">
            <label>Book Thumbnail</label>
            <input type="file" name="book_thumb_image" class="form-control">
        </div>

        <div class="mb-3">
            <label>Book PDF</label>
            <input type="file" name="book_pdf" class="form-control">
        </div>

        <div class="mb-3">
            <label>Select Language</label>
            <select name="language_id" class="form-control" required>
                <option value="">-- Select --</option>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($lang->id); ?>"><?php echo e($lang->language_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Select Category</label>
            <select name="category_id" class="form-control" required>
                <option value="">-- Select --</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button class="btn btn-success">Save</button>
        <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">Back</a>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/books/create.blade.php ENDPATH**/ ?>