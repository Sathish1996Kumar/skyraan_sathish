<?php $__env->startSection('content'); ?>
    <style>
        .scroll-wrapper {
            position: relative;
        }

        .related-books-container {
            overflow-x: auto;
            padding-bottom: 10px;
            scrollbar-width: none;
            /* Firefox */
        }

        .related-books-container::-webkit-scrollbar {
            display: none;
            /* Chrome/Safari */
        }

        .scroll-row {
            display: flex;
            gap: 15px;
            white-space: nowrap;
        }

        .book-item {
            min-width: 180px;
            flex-shrink: 0;
        }

        .scroll-btn {
            position: absolute;
            top: 40%;
            background: #343a40;
            color: #fff;
            border: none;
            padding: 10px 12px;
            border-radius: 50%;
            cursor: pointer;
            z-index: 10;
            opacity: 0.7;
            transition: 0.2s;
        }

        .scroll-btn:hover {
            opacity: 1;
        }

        .left-btn {
            left: -10px;
        }

        .right-btn {
            right: -10px;
        }
    </style>
    <div class="container py-4">

        
        <div class="row mb-5">
            <div class="col-md-4">
                <?php if($book->book_thumb_image): ?>
                    <img src="<?php echo e(asset('uploads/books/thumb/' . $book->book_thumb_image)); ?>" class="img-fluid rounded shadow" style="max-height: 350px;"
                        alt="<?php echo e($book->book_name); ?>">
                <?php else: ?>
                    <img src="<?php echo e(asset('uploads/books/thumb/default.png')); ?>" class="img-fluid rounded" alt="Default">
                <?php endif; ?>
            </div>

            <div class="col-md-8">
                <h2 class="fw-bold"><?php echo e($book->book_name); ?></h2>

                <h5 class="text-muted mb-2">
                    <strong>Author:</strong> <?php echo e($book->author); ?>

                </h5>

                <h5 class="text-muted mb-2">
                    <strong>Publish Date:</strong> <?php echo e($book->publisher_date); ?>

                </h5>

            </div>

            <div class="mt-4">
                <?php if($book->book_pdf): ?>
                    <a href="<?php echo e(Storage::disk('s3')->url('books/pdf/' . $book->book_pdf)); ?>" target="_blank"
                        class="btn btn-primary">
                        📄 PREVIEW
                    </a>
                <?php endif; ?>
            </div>
            <div class="mt-3">
                <h5 class="text-muted mb-2">
                    <strong>ABOUT BOOK</strong>
                </h5>
                <p class="mb-4"><?php echo e($book->description); ?></p>
                <h5 class="text-muted mb-2">
                    <strong>More Info</strong>
                </h5>


                <p class="text-muted mb-2">
                    <strong>Lannguage:</strong> <?php echo e($book->language->language_name); ?>

                </p>

                <p class="text-muted mb-2">
                    <strong>Published Date:</strong> <?php echo e($book->publisher_date); ?>

                </p>

                <p class="text-muted mb-2">
                    <strong>Category:</strong> <?php echo e($book->category->category_name); ?>

                </p>

            </div>

        </div>


        
        <h4 class="mb-3">Related Books</h4>

        <div class="scroll-wrapper">

            <!-- Left Arrow -->
            <button class="scroll-btn left-btn">&#10094;</button>

            <!-- Scrollable Content -->
            <div class="related-books-container" id="relatedScroll">
                <div class="scroll-row">
                    <?php $__empty_1 = true; $__currentLoopData = $relatedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="book-item">
                            <a href="<?php echo e(route('books.show', ['category_id' => $rbook->category_id, 'book_id' => $rbook->id])); ?>"
                                style="text-decoration:none; color:inherit;">
                                <div class="card shadow-sm">
                                    <?php if($rbook->book_thumb_image): ?>
                                        <img src="<?php echo e(asset('uploads/books/thumb/' . $rbook->book_thumb_image)); ?>"
                                            class="card-img-top" style="height:140px; object-fit:cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('uploads/books/thumb/default.png')); ?>" class="card-img-top">
                                    <?php endif; ?>

                                    <div class="card-body text-center">
                                        <h6 class="card-title"><?php echo e($rbook->book_name); ?></h6>
                                        <small class="text-muted"><?php echo e($rbook->author); ?></small>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No related books found.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Arrow -->
            <button class="scroll-btn right-btn">&#10095;</button>

        </div>


    </div>

    <script>
        const container = document.getElementById('relatedScroll');
        const leftBtn = document.querySelector('.left-btn');
        const rightBtn = document.querySelector('.right-btn');

        rightBtn.addEventListener('click', () => {
            container.scrollBy({
                left: 250,
                behavior: 'smooth'
            });
        });

        leftBtn.addEventListener('click', () => {
            container.scrollBy({
                left: -250,
                behavior: 'smooth'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/books/detail.blade.php ENDPATH**/ ?>