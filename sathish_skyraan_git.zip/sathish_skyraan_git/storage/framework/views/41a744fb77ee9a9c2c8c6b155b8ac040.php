<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h2>Add Category</h2>

    <form method="POST" action="<?php echo e(route('categories.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Category Name</label>
            <input type="text" name="category_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label>Category Image</label>
            <input type="file" name="category_image" class="form-control">
        </div>

        <button class="btn btn-success">Save</button>
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/categories/create.blade.php ENDPATH**/ ?>