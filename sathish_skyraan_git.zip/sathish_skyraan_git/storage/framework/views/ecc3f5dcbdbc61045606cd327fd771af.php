<?php $__env->startSection('title', $category->category_name . ' Books'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><?php echo e($category->category_name); ?> Books</h2>

        <!-- Language Filter -->
        <form method="GET" action="<?php echo e(route('web.category.books', $category->id)); ?>">
            <select name="language_id" class="form-select" onchange="this.form.submit()">
                <option value="">All Languages</option>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($language->id); ?>" <?php echo e(request('language_id') == $language->id ? 'selected' : ''); ?>>
                        <?php echo e($language->language_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>
    </div>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 col-sm-6 mb-4">
                <a href="<?php echo e(route('books.show', ['category_id' => $book->category_id, 'book_id' => $book->id])); ?>"
                    style="text-decoration:none; color:inherit;">
                    <div class="card shadow-sm">
                        <?php if($book->book_thumb_image): ?>
                            <img src="<?php echo e(asset('uploads/books/thumb/' . $book->book_thumb_image)); ?>" class="card-img-top"
                                style="max-height:160px; object-fit:cover;" alt="<?php echo e($book->book_name); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(asset('uploads/books/thumb/default.png')); ?>" class="card-img-top" alt="Default">
                        <?php endif; ?>

                        <div class="card-body text-center">
                            <h5 class="card-title"><?php echo e($book->book_name); ?></h5>
                            <p class="mb-1">Author: <?php echo e($book->author); ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center">
                <p>No books available in this category.</p>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/web/category_books.blade.php ENDPATH**/ ?>