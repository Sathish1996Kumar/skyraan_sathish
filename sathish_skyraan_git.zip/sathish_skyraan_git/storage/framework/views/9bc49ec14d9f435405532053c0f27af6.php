<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Book Website'); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .category-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .category-card {
            margin-bottom: 20px;
        }

        .topbar {
            background-color: #343a40;
        }

        .topbar .navbar-brand,
        .topbar .nav-link {
            color: #fff !important;
        }

        .footer {
            background-color: #343a40;
            color: #fff;
            padding: 15px 0;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>

<body>

    <!-- Topbar / Navbar -->
    <nav class="navbar navbar-expand-lg topbar">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('web.books')); ?>">My Book Store</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('web.books')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Footer -->
    <div class="footer text-center mt-5">
        <p>&copy; <?php echo e(date('Y')); ?> My Book Store | All rights reserved</p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/layouts/web.blade.php ENDPATH**/ ?>