<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <h2>Books List</h2>

        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary mb-3">Add Book</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success flash-message"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered" id="booksTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Thumb</th>
                    <th>Name</th>
                    <th>Author</th>
                    <th>Language</th>
                    <th>Category</th>
                    <th>PDF</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>

                        <td>
                            <?php if($book->book_thumb_image): ?>
                                <img src="<?php echo e(asset('uploads/books/thumb/' . $book->book_thumb_image)); ?>" width="70"
                                    style="max-height: 50px;">
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($book->book_name); ?></td>
                        <td><?php echo e($book->author); ?></td>
                        <td><?php echo e($book->language->language_name); ?></td>
                        <td><?php echo e($book->category->category_name); ?></td>

                        <td>
                            <?php if($book->book_pdf): ?>
                                

                                <a href="<?php echo e(Storage::disk('s3')->url('books/pdf/' . $book->book_pdf)); ?>" target="_blank">
                                    Preview
                                </a>
                            <?php endif; ?>
                        </td>

                        <td>
                            <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a onclick="return confirm('Delete this book?')" href="<?php echo e(route('books.delete', $book->id)); ?>"
                                class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS & JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <!-- DataTables Responsive -->
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>

    <!-- Initialize DataTables -->
    <script>
        $(document).ready(function() {
            $('#booksTable').DataTable({
                responsive: true, // Makes table responsive
                pageLength: 10, // Rows per page
                ordering: true, // Enable sorting
                info: true, // Show table info
                searching: true, // Enable search
                lengthChange: true, // Allow user to change rows per page
                autoWidth: false
            });
        });

        setTimeout(function() {
            let messages = document.querySelectorAll('.flash-message');
            messages.forEach(function(msg) {
                msg.style.transition = "opacity 0.5s";
                msg.style.opacity = "0";
                setTimeout(() => msg.remove(), 500);
            });
        }, 2000); // 3 seconds
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/books/index.blade.php ENDPATH**/ ?>