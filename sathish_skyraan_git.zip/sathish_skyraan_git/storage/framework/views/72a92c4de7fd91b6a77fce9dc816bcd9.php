<?php $__env->startSection('title', 'Book Categories'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-4 text-center">Book Categories</h2>

    <div class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <a href="<?php echo e(route('web.category.books', $category->id)); ?>" class="text-decoration-none">
                    <div class="card category-card">
                        <?php if($category->category_image): ?>
                            <img src="<?php echo e(asset('uploads/category/' . $category->category_image)); ?>" class="card-img-top"
                                alt="<?php echo e($category->category_name); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(asset('uploads/category/default.png')); ?>" class="card-img-top" alt="Default">
                        <?php endif; ?>
                        <div class="card-body text-center">
                            <h5 class="card-title text-dark"><?php echo e($category->category_name); ?></h5>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <hr class="my-5">

    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->books->count() > 0): ?>
            <h3 class="mt-4"><?php echo e($category->category_name); ?></h3>
            <div class="row mb-4">
                <?php $__currentLoopData = $category->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6">
                        <div class="card book-card">
                            <?php if($book->book_thumb_image): ?>
                                <img src="<?php echo e(asset('uploads/books/thumb/' . $book->book_thumb_image)); ?>" style="max-height:150px;"
                                    class="card-img-top" alt="<?php echo e($book->title); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('uploads/books/default.png')); ?>" class="card-img-top" alt="Default">
                            <?php endif; ?>
                            <div class="card-body text-center">
                                <p class="mb-1">Author: <?php echo e($book->author); ?></p>
                                <h5 class="card-title text-dark"><?php echo e($book->book_name); ?></h5>
                                

                                <a class="btn btn-primary btn-sm"
                                    href="<?php echo e(Storage::disk('s3')->url('books/pdf/' . $book->book_pdf)); ?>" target="_blank">
                                    Preview
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\sathish_skyraan\resources\views/web/books.blade.php ENDPATH**/ ?>