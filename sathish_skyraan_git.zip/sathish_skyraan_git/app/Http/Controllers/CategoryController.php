<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return view('categories.index', compact('categories'));
    }

    // Show Create Form
    public function create()
    {
        return view('categories.create');
    }

    // Store Category
    public function store(Request $request)
    {

        $request->validate([
            'category_name' => 'required',
            'description'   => 'nullable',
            'category_image' => 'image|mimes:jpg,png,jpeg,gif|max:2048',
        ]);

        $imageName = null;
        if ($request->hasFile('category_image')) {
            $imageName = time().'.'.$request->category_image->extension();
            $request->category_image->move(public_path('uploads/category'), $imageName);
        }

        Category::create([
            'category_name' => $request->category_name,
            'description' => $request->description,
            'category_image' => $imageName,
        ]);

        return redirect()->route('categories.index')->with('success','Category Added!');
    }

    // Show Edit Form
    public function edit($id)
    {
        $category = Category::findOrFail($id);
        return view('categories.edit', compact('category'));
    }

    // Update Category
    public function update(Request $request, $id)
    {
        $request->validate([
            'category_name' => 'required',
            'category_image' => 'image|mimes:jpg,png,jpeg,gif|max:2048',
        ]);

        $category = Category::findOrFail($id);

        $imageName = $category->category_image;
        if ($request->hasFile('category_image')) {
            $imageName = time().'.'.$request->category_image->extension();
            $request->category_image->move(public_path('uploads/category'), $imageName);
        }

        $category->update([
            'category_name' => $request->category_name,
            'description' => $request->description,
            'category_image' => $imageName,
        ]);

        return redirect()->route('categories.index')->with('success','Category Updated!');
    }

    // Delete Category
    public function delete($id)
    {
        $category = Category::findOrFail($id);

        $bookCategory = Book::where('category_id',$id)->get();
        if (count($bookCategory) === 0) {
            if ($category->category_image && file_exists(public_path('uploads/category/'.$category->category_image))) {
                unlink(public_path('uploads/category/'.$category->category_image));
            }

            $category->delete();
            return redirect()->back()->with('success','Category Deleted!');
        }else{
            return redirect()->back()->with('failure','Category Mapped to Book!');
        }

    }

}
