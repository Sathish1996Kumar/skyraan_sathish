<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Category;
use App\Models\Language;
use Illuminate\Support\Facades\Storage;

class BookController extends Controller
{
    // Show All Books
    public function index()
    {
        $books = Book::with(['category', 'language'])->get();
        return view('books.index', compact('books'));
    }

    // Show Create Form
    public function create()
    {
        $categories = Category::all();
        $languages  = Language::all();
        return view('books.create', compact('categories', 'languages'));
    }

    // Store Book
    public function store(Request $request)
    {
        $request->validate([
            'book_name' => 'required',
            'author'    => 'required',
            'publisher_date' => 'date|nullable',
            'book_thumb_image' => 'image|mimes:jpg,png,jpeg|max:2048',
            'book_pdf' => 'mimes:pdf|max:5000',
            'language_id' => 'required',
            'category_id' => 'required',
        ]);

        // Image Upload
        $thumb = null;
        if ($request->hasFile('book_thumb_image')) {
            $thumb = time() . '_thumb.' . $request->book_thumb_image->extension();
            $request->book_thumb_image->move(public_path('uploads/books/thumb'), $thumb);
        }

        // PDF Upload
        $pdf = null;
        // if ($request->hasFile('book_pdf')) {
        //     $pdf = time() . '_book.' . $request->book_pdf->extension();
        //     $request->book_pdf->move(public_path('uploads/books/pdf'), $pdf);
        // }

        if ($request->hasFile('book_pdf')) {
            $pdf = time() . '_book.' . $request->book_pdf->extension();
            Storage::disk('s3')->put('books/pdf/' . $pdf, file_get_contents($request->book_pdf));
        }

        Book::create([
            'book_name' => $request->book_name,
            'description' => $request->description,
            'author' => $request->author,
            'publisher_date' => $request->publisher_date,
            'book_thumb_image' => $thumb,
            'book_pdf' => $pdf,
            'language_id' => $request->language_id,
            'category_id' => $request->category_id,
        ]);

        return redirect()->route('books.index')->with('success', 'Book Added Successfully!');
    }

    // Edit Book
    public function edit($id)
    {
        $book = Book::findOrFail($id);
        $categories = Category::all();
        $languages  = Language::all();

        return view('books.edit', compact('book', 'categories', 'languages'));
    }

    // Update Book
    public function update(Request $request, $id)
    {
        $book = Book::findOrFail($id);

        $request->validate([
            'book_name' => 'required',
            'author'    => 'required',
            'publisher_date' => 'date|nullable',
            'book_thumb_image' => 'mimes:jpg,png,jpeg|max:2048',
            'book_pdf' => 'mimes:pdf|max:5000',
            'language_id' => 'required',
            'category_id' => 'required',
        ]);

        $thumb = $book->book_thumb_image;
        if ($request->hasFile('book_thumb_image')) {
            $thumb = time() . "_thumb." . $request->book_thumb_image->extension();
            $request->book_thumb_image->move(public_path('uploads/books/thumb'), $thumb);
        }

        $pdf = $book->book_pdf;
        // if ($request->hasFile('book_pdf')) {
        //     $pdf = time() . "_book." . $request->book_pdf->extension();
        //     $request->book_pdf->move(public_path('uploads/books/pdf'), $pdf);
        // }

        if ($request->hasFile('book_pdf')) {
            $pdf = time() . '_book.' . $request->book_pdf->extension();
            Storage::disk('s3')->put('books/pdf/' . $pdf, file_get_contents($request->book_pdf));
        }


        $book->update([
            'book_name' => $request->book_name,
            'description' => $request->description,
            'author' => $request->author,
            'publisher_date' => $request->publisher_date,
            'book_thumb_image' => $thumb,
            'book_pdf' => $pdf,
            'language_id' => $request->language_id,
            'category_id' => $request->category_id,
        ]);

        return redirect()->route('books.index')->with('success', 'Book Updated Successfully!');
    }

    // Delete Book
    public function delete($id)
    {
        $book = Book::findOrFail($id);

        // Delete files
        if ($book->book_thumb_image && file_exists(public_path('uploads/books/thumb/' . $book->book_thumb_image))) {
            unlink(public_path('uploads/books/thumb/' . $book->book_thumb_image));
        }

        if ($book->book_pdf && file_exists(public_path('uploads/books/pdf/' . $book->book_pdf))) {
            unlink(public_path('uploads/books/pdf/' . $book->book_pdf));
        }

        $book->delete();

        return redirect()->back()->with('success', 'Book Deleted Successfully!');
    }
}
