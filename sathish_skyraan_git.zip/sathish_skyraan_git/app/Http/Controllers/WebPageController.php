<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Language;
use Illuminate\Http\Request;
use App\Models\Category;

class WebPageController extends Controller
{

    public function books()
    {
        // Get all categories with books
        $categories = Category::with('books')->get(); // eager load books

        return view('web.books', compact('categories'));
    }



    // Show categories page
    public function categories()
    {
        $categories = Category::all();
        return view('web.categories', compact('categories'));
    }

    // Show books in a category (with optional language filter)
    public function categoryBooks(Request $request, $id)
    {
        $languages = Language::all();
        $category = Category::findOrFail($id);

        $books = Book::where('category_id', $id);

        // Filter by language if selected
        if ($request->has('language_id') && $request->language_id != '') {
            $books->where('language_id', $request->language_id);
        }

        $books = $books->get();

        return view('web.category_books', compact('books', 'languages', 'category'));
    }

    public function show($category_id, $book_id)
    {
        $book = Book::findOrFail($book_id);

        // Get related books from same category
        $relatedBooks = Book::where('category_id', $category_id)
            ->where('id', '!=', $book_id)
            ->limit(8)
            ->get();

        return view('books.detail', compact('book', 'relatedBooks'));
    }
}
