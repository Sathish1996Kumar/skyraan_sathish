<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    protected $fillable = [
        'book_name',
        'description',
        'author',
        'publisher_date',
        'book_thumb_image',
        'book_pdf',
        'language_id',
        'category_id',
    ];

    // Book belongs to a Category
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    // Book belongs to a Language
    public function language()
    {
        return $this->belongsTo(Language::class);
    }
}
