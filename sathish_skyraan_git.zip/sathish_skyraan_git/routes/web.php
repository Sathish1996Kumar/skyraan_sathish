<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\WebPageController;

Route::get('/', function () {
    return view('welcome');
});

Route::view('/dashboard', 'dashboard')->name('dashboard');
Route::view('/category', 'dashboard')->name('category');

Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');
Route::get('/categories/create', [CategoryController::class, 'create'])->name('categories.create');
Route::post('/categories/store', [CategoryController::class, 'store'])->name('categories.store');

Route::get('/categories/edit/{id}', [CategoryController::class, 'edit'])->name('categories.edit');
Route::post('/categories/update/{id}', [CategoryController::class, 'update'])->name('categories.update');

Route::get('/categories/delete/{id}', [CategoryController::class, 'delete'])->name('categories.delete');

Route::get('/books', [BookController::class,'index'])->name('books.index');
Route::get('/books/create', [BookController::class,'create'])->name('books.create');
Route::post('/books/store', [BookController::class,'store'])->name('books.store');

Route::get('/books/edit/{id}', [BookController::class,'edit'])->name('books.edit');
Route::post('/books/update/{id}', [BookController::class,'update'])->name('books.update');

Route::get('/books/delete/{id}', [BookController::class,'delete'])->name('books.delete');

Route::get('/books_web', [WebPageController::class, 'books'])->name('web.books');

Route::get('/books/categories', [WebPageController::class, 'categories'])->name('web.categories');

Route::get('/books/category/{id}', [WebPageController::class, 'categoryBooks'])->name('web.category.books');

Route::get('/book_detail/{category_id}/{book_id}', [WebPageController::class, 'show'])->name('books.show');
