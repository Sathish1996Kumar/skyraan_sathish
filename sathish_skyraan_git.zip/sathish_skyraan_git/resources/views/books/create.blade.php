@extends('layouts.admin')

@section('content')
<div class="container mt-4">

    <h2>Add Book</h2>

    <form action="{{ route('books.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label>Book Name</label>
            <input type="text" name="book_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label>Author</label>
            <input type="text" name="author" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Publisher Date</label>
            <input type="date" name="publisher_date" class="form-control">
        </div>

        <div class="mb-3">
            <label>Book Thumbnail</label>
            <input type="file" name="book_thumb_image" class="form-control">
        </div>

        <div class="mb-3">
            <label>Book PDF</label>
            <input type="file" name="book_pdf" class="form-control">
        </div>

        <div class="mb-3">
            <label>Select Language</label>
            <select name="language_id" class="form-control" required>
                <option value="">-- Select --</option>
                @foreach($languages as $lang)
                <option value="{{ $lang->id }}">{{ $lang->language_name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Select Category</label>
            <select name="category_id" class="form-control" required>
                <option value="">-- Select --</option>
                @foreach($categories as $cat)
                <option value="{{ $cat->id }}">{{ $cat->category_name }}</option>
                @endforeach
            </select>
        </div>

        <button class="btn btn-success">Save</button>
        <a href="{{ route('books.index') }}" class="btn btn-secondary">Back</a>
    </form>

</div>
@endsection
