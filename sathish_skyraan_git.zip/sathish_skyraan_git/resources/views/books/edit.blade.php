@extends('layouts.admin')

@section('content')
<div class="container mt-4">

    <h2>Edit Book</h2>

    <form action="{{ route('books.update', $book->id) }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label>Book Name</label>
            <input type="text" name="book_name" class="form-control" value="{{ $book->book_name }}" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control">{{ $book->description }}</textarea>
        </div>

        <div class="mb-3">
            <label>Author</label>
            <input type="text" name="author" class="form-control" value="{{ $book->author }}" required>
        </div>

        <div class="mb-3">
            <label>Publisher Date</label>
            <input type="date" name="publisher_date" class="form-control" value="{{ $book->publisher_date }}">
        </div>

        <div class="mb-3">
            <label>Current Thumbnail</label><br>
            @if($book->book_thumb_image)
                <img src="{{ asset('uploads/books/thumb/'.$book->book_thumb_image) }}" width="90"><br><br>
            @endif
        </div>

        <div class="mb-3">
            <label>Upload New Thumbnail</label>
            <input type="file" name="book_thumb_image" class="form-control">
        </div>

        <div class="mb-3">
            <label>Current PDF</label><br>
            @if($book->book_pdf)
                <a href="{{ asset('uploads/books/pdf/'.$book->book_pdf) }}" target="_blank">Open PDF</a><br><br>
            @endif
        </div>

        <div class="mb-3">
            <label>Upload New PDF</label>
            <input type="file" name="book_pdf" class="form-control">
        </div>

        <div class="mb-3">
            <label>Select Language</label>
            <select name="language_id" class="form-control" required>
                @foreach($languages as $lang)
                    <option value="{{ $lang->id }}" {{ $book->language_id == $lang->id ? 'selected' : '' }}>
                        {{ $lang->language_name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Select Category</label>
            <select name="category_id" class="form-control" required>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ $book->category_id == $cat->id ? 'selected' : '' }}>
                        {{ $cat->category_name }}
                    </option>
                @endforeach
            </select>
        </div>

        <button class="btn btn-success">Update</button>
        <a href="{{ route('books.index') }}" class="btn btn-secondary">Back</a>

    </form>

</div>
@endsection
