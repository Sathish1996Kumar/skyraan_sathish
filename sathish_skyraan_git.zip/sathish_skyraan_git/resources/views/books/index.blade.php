@extends('layouts.admin')

@section('content')
    <div class="container mt-4">

        <h2>Books List</h2>

        <a href="{{ route('books.create') }}" class="btn btn-primary mb-3">Add Book</a>

        @if (session('success'))
            <div class="alert alert-success flash-message">{{ session('success') }}</div>
        @endif

        <table class="table table-bordered" id="booksTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Thumb</th>
                    <th>Name</th>
                    <th>Author</th>
                    <th>Language</th>
                    <th>Category</th>
                    <th>PDF</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($books as $key => $book)
                    <tr>
                        <td>{{ $key + 1 }}</td>

                        <td>
                            @if ($book->book_thumb_image)
                                <img src="{{ asset('uploads/books/thumb/' . $book->book_thumb_image) }}" width="70"
                                    style="max-height: 50px;">
                            @endif
                        </td>

                        <td>{{ $book->book_name }}</td>
                        <td>{{ $book->author }}</td>
                        <td>{{ $book->language->language_name }}</td>
                        <td>{{ $book->category->category_name }}</td>

                        <td>
                            @if ($book->book_pdf)
                                {{-- <a href="{{ asset('uploads/books/pdf/' . $book->book_pdf) }}" target="_blank">Preview</a> --}}

                                <a href="{{ Storage::disk('s3')->url('books/pdf/' . $book->book_pdf) }}" target="_blank">
                                    Preview
                                </a>
                            @endif
                        </td>

                        <td>
                            <a href="{{ route('books.edit', $book->id) }}" class="btn btn-warning btn-sm">Edit</a>
                            <a onclick="return confirm('Delete this book?')" href="{{ route('books.delete', $book->id) }}"
                                class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS & JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <!-- DataTables Responsive -->
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>

    <!-- Initialize DataTables -->
    <script>
        $(document).ready(function() {
            $('#booksTable').DataTable({
                responsive: true, // Makes table responsive
                pageLength: 10, // Rows per page
                ordering: true, // Enable sorting
                info: true, // Show table info
                searching: true, // Enable search
                lengthChange: true, // Allow user to change rows per page
                autoWidth: false
            });
        });

        setTimeout(function() {
            let messages = document.querySelectorAll('.flash-message');
            messages.forEach(function(msg) {
                msg.style.transition = "opacity 0.5s";
                msg.style.opacity = "0";
                setTimeout(() => msg.remove(), 500);
            });
        }, 2000); // 3 seconds
    </script>
@endsection
