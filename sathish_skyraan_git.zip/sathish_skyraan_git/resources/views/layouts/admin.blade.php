<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f5f7;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1e1e2d;
            color: white;
            position: fixed;
            left: 0;
        }
        .sidebar a {
            color: #c9c9d4;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            font-size: 15px;
        }
        .sidebar a:hover {
            background: #2b2b3c;
            color: #fff;
        }
        .sidebar .active {
            background: #4c4cef;
            color: white;
        }
        .content {
            margin-left: 250px;
            padding: 30px;
        }
        .sidebar-title {
            font-size: 20px;
            padding: 20px;
            text-align: center;
            background: #151521;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-title">Admin Panel</div>

    <a href="{{route('dashboard')}}" class="{{ request()->is('dashboard') ? 'active' : '' }}">Dashboard</a>

    <a href="{{route('categories.index')}}" class="{{ request()->is('category*') ? 'active' : '' }}">Categories</a>

    <a href="{{route('books.index')}}" class="{{ request()->is('books_admin*') ? 'active' : '' }}">Books</a>

</div>

<div class="content">
    @yield('content')
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

@stack('scripts')

</body>
</html>
