@extends('layouts.web')

@section('title', $category->category_name . ' Books')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>{{ $category->category_name }} Books</h2>

        <!-- Language Filter -->
        <form method="GET" action="{{ route('web.category.books', $category->id) }}">
            <select name="language_id" class="form-select" onchange="this.form.submit()">
                <option value="">All Languages</option>
                @foreach ($languages as $language)
                    <option value="{{ $language->id }}" {{ request('language_id') == $language->id ? 'selected' : '' }}>
                        {{ $language->language_name }}
                    </option>
                @endforeach
            </select>
        </form>
    </div>

    <div class="row">
        @forelse($books as $book)
            <div class="col-md-3 col-sm-6 mb-4">
                <a href="{{ route('books.show', ['category_id' => $book->category_id, 'book_id' => $book->id]) }}"
                    style="text-decoration:none; color:inherit;">
                    <div class="card shadow-sm">
                        @if ($book->book_thumb_image)
                            <img src="{{ asset('uploads/books/thumb/' . $book->book_thumb_image) }}" class="card-img-top"
                                style="max-height:160px; object-fit:cover;" alt="{{ $book->book_name }}">
                        @else
                            <img src="{{ asset('uploads/books/thumb/default.png') }}" class="card-img-top" alt="Default">
                        @endif

                        <div class="card-body text-center">
                            <h5 class="card-title">{{ $book->book_name }}</h5>
                            <p class="mb-1">Author: {{ $book->author }}</p>
                        </div>
                    </div>
                </a>
            </div>
        @empty
            <div class="col-12 text-center">
                <p>No books available in this category.</p>
            </div>
        @endforelse

    </div>
@endsection
