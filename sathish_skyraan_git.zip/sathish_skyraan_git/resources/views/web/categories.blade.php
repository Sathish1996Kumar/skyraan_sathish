@extends('layouts.web')

@section('title', 'Book Categories')

@section('content')
<h2 class="mb-4 text-center">Book Categories</h2>

<div class="row">
    @foreach($categories as $category)
        <div class="col-md-3 col-sm-6">
            <div class="card category-card">
                <a href="{{ route('web.category.books', $category->id) }}">
                    @if($category->category_image)
                        <img src="{{ asset('uploads/category/' . $category->category_image) }}" class="card-img-top" alt="{{ $category->category_name }}">
                    @else
                        <img src="{{ asset('uploads/category/default.png') }}" class="card-img-top" alt="Default">
                    @endif
                </a>
                <div class="card-body text-center">
                    <h5 class="card-title">{{ $category->category_name }}</h5>
                </div>
            </div>
        </div>
    @endforeach
</div>
@endsection
