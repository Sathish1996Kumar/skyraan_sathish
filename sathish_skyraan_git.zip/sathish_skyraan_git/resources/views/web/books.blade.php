{{-- @extends('layouts.web')

@section('title', 'Book Categories')

@section('content')
    <h2 class="mb-4 text-center">Book Categories</h2>

    <div class="row">
        @foreach ($categories as $category)
            <div class="col-md-3 col-sm-6">
                <a href="{{ route('web.category.books', $category->id) }}" class="text-decoration-none">
                    <div class="card category-card">
                        @if ($category->category_image)
                            <img src="{{ asset('uploads/category/' . $category->category_image) }}" class="card-img-top"
                                alt="{{ $category->category_name }}">
                        @else
                            <img src="{{ asset('uploads/category/default.png') }}" class="card-img-top" alt="Default">
                        @endif
                        <div class="card-body text-center">
                            <h5 class="card-title text-dark">{{ $category->category_name }}</h5>
                        </div>
                    </div>
                </a>
            </div>
        @endforeach
    </div>
@endsection --}}


@extends('layouts.web')

@section('title', 'Book Categories')

@section('content')
    <h2 class="mb-4 text-center">Book Categories</h2>

    <div class="row">
        @foreach ($categories as $category)
            <div class="col-md-3 col-sm-6">
                <a href="{{ route('web.category.books', $category->id) }}" class="text-decoration-none">
                    <div class="card category-card">
                        @if ($category->category_image)
                            <img src="{{ asset('uploads/category/' . $category->category_image) }}" class="card-img-top"
                                alt="{{ $category->category_name }}">
                        @else
                            <img src="{{ asset('uploads/category/default.png') }}" class="card-img-top" alt="Default">
                        @endif
                        <div class="card-body text-center">
                            <h5 class="card-title text-dark">{{ $category->category_name }}</h5>
                        </div>
                    </div>
                </a>
            </div>
        @endforeach
    </div>

    <hr class="my-5">

    {{-- Books by Category --}}
    @foreach ($categories as $category)
        @if ($category->books->count() > 0)
            <h3 class="mt-4">{{ $category->category_name }}</h3>
            <div class="row mb-4">
                @foreach ($category->books as $book)
                    <div class="col-md-3 col-sm-6">
                        <div class="card book-card">
                            @if ($book->book_thumb_image)
                                <img src="{{ asset('uploads/books/thumb/' . $book->book_thumb_image) }}" style="max-height:150px;"
                                    class="card-img-top" alt="{{ $book->title }}">
                            @else
                                <img src="{{ asset('uploads/books/default.png') }}" class="card-img-top" alt="Default">
                            @endif
                            <div class="card-body text-center">
                                <p class="mb-1">Author: {{ $book->author }}</p>
                                <h5 class="card-title text-dark">{{ $book->book_name }}</h5>
                                {{-- <a href="{{ $book->book_pdf ? asset('uploads/books/pdf/' . $book->book_pdf) : '#' }}"
                                    class="btn btn-primary btn-sm" target="_blank">
                                    Preview
                                </a> --}}

                                <a class="btn btn-primary btn-sm"
                                    href="{{ Storage::disk('s3')->url('books/pdf/' . $book->book_pdf) }}" target="_blank">
                                    Preview
                                </a>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    @endforeach
@endsection
