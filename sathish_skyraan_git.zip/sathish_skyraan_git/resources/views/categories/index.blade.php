@extends('layouts.admin')

@section('content')
    <div class="container mt-4">

        <h2>Category List</h2>

        <a href="{{ route('categories.create') }}" class="btn btn-primary mb-3">Add Category</a>

        @if (session('success'))
            <div class="alert alert-success flash-message">{{ session('success') }}</div>
        @endif
        @if (session('failure'))
            <div class="alert alert-danger flash-message">{{ session('failure') }}</div>
        @endif

        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Action</th>
            </tr>

            @foreach ($categories as $cat)
                <tr>
                    <td>{{ $cat->id }}</td>
                    <td>{{ $cat->category_name }}</td>
                    <td>{{ $cat->description }}</td>
                    <td>
                        @if ($cat->category_image)
                            <img src="{{ asset('uploads/category/' . $cat->category_image) }}" width="80" style="max-height:70px;">
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('categories.edit', $cat->id) }}" class="btn btn-sm btn-warning">Edit</a>
                        <a href="{{ route('categories.delete', $cat->id) }}" class="btn btn-sm btn-danger"
                            onclick="return confirm('Delete?')">Delete</a>
                    </td>
                </tr>
            @endforeach
        </table>
    </div>
@endsection

<script>
    setTimeout(function() {
        let messages = document.querySelectorAll('.flash-message');
        messages.forEach(function(msg) {
            msg.style.transition = "opacity 0.5s";
            msg.style.opacity = "0";
            setTimeout(() => msg.remove(), 500);
        });
    }, 2000); // 3 seconds
</script>
