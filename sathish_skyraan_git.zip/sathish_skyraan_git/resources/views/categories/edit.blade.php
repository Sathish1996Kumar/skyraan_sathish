@extends('layouts.admin')

@section('content')
<div class="container mt-4">

    <h2>Edit Category</h2>

    <form method="POST" action="{{ route('categories.update', $category->id) }}" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label>Category Name</label>
            <input type="text" value="{{ $category->category_name }}" name="category_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control">{{ $category->description }}</textarea>
        </div>

        <div class="mb-3">
            <label>Current Image</label><br>
            @if($category->category_image)
                <img src="{{ asset('uploads/category/'.$category->category_image) }}" width="100"><br><br>
            @endif
        </div>

        <div class="mb-3">
            <label>Upload New Image</label>
            <input type="file" name="category_image" class="form-control">
        </div>

        <button class="btn btn-success">Update</button>
        <a href="{{ route('categories.index') }}" class="btn btn-secondary">Back</a>
    </form>
</div>
@endsection
