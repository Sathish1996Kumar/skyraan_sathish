@extends('layouts.admin')

@section('content')
<h2>Dashboard</h2>
<p>Welcome to your admin panel!</p>
@endsection
