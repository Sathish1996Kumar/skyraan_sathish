composer create-project laravel/laravel sathish_skyraan

php artisan make:migration create_categories_table

php artisan migrate

php artisan make:model Category

php artisan make:controller CategoryController

php artisan make:migration create_languages_table

php artisan make:model Language

php artisan make:seeder LanguageSeeder

php artisan migrate --seed

php artisan make:migration create_books_table

php artisan migrate

php artisan make:model Book

php artisan make:controller BookController

php artisan make:controller WebPageController

composer require league/flysystem-aws-s3-v3 "^3.0"

php artisan config:clear

php artisan cache:clear

php artisan optimize:clear
